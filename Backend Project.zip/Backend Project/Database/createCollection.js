import {default as mongodb} from 'mongodb';
const MongoClient = mongodb.MongoClient;
const url = 'mongodb://localhost:27017';

// this creates collection in database
export const createCollection = (myCollection) => {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            throw err;
        }
        const dbo = db.db('mydb');
        dbo.createCollection(myCollection, (err, res) => {
            if (err) {
                throw err;
            }
            db.close();
        })
    })
}