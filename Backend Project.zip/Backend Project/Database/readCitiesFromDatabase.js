import { showInHTMLFormat } from '../HTML Format/htmlFormat.js';
import {default as mongodb} from 'mongodb';
const MongoClient = mongodb.MongoClient;
const url = 'mongodb://localhost:27017';

// this reads all cities from database
// and displays it on server
export const readCitiesFromDatabase = (res) => {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            throw err;
        }
        const dbo = db.db('mydb');
        dbo.collection('Cities').find().toArray((err, result) => {
            if (err) {
                throw err;
            }
            showInHTMLFormat(result, res);
            db.close();
        })
    })
}