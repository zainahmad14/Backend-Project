import { createCollection } from './createCollection.js';
import { storeListAsObjectArray } from '../CSV Object/storeListAsCSVObject.js';
import {default as mongodb} from 'mongodb';
const MongoClient = mongodb.MongoClient;
const url = 'mongodb://localhost:27017';

// this inserts list in collection
// on database
export const insertListInCollection = async () => {
    // this stores list of csv files 
    // in object array
    const provinceCSvObjectArray = await storeListAsObjectArray('./Cities/Replaced/Province.csv')
    const azadKashmirCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/AzadKashmir.csv');
    const BalochistanCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/Balochistan.csv');
    const BaltistanCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/Baltistan.csv');
    const FederalTribalAreasCSvObjectArray = await storeListAsObjectArray('./Cities/Replaced/FederalTribalAreas.csv');
    const IslamabadCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/Islamabad.csv');
    const KhyberPakhtunkhwaCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/KhyberPakhtunkhwa.csv');
    const PunjabCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/Punjab.csv');
    const SindhCSVObjectArray = await storeListAsObjectArray('./Cities/Replaced/Sindh.csv');
    // this concatenate all CSVObjectArray
    // in listCSVObjectArray
    const listCSVObjectArray = provinceCSvObjectArray.concat(
        azadKashmirCSVObjectArray).concat(
            BalochistanCSVObjectArray).concat(
                BaltistanCSVObjectArray).concat(
                    FederalTribalAreasCSvObjectArray).concat(
                        IslamabadCSVObjectArray).concat(KhyberPakhtunkhwaCSVObjectArray).concat(
                            PunjabCSVObjectArray).concat(SindhCSVObjectArray);
        // stores 'Cities' in myCollection
        const myCollection = 'Cities';
        // this creates collection in database
        createCollection(myCollection);
        MongoClient.connect(url, (err, db) => {
        if (err) {
            throw err;
        }
        const dbo = db.db('mydb');
        dbo.collection(myCollection).insertMany(listCSVObjectArray, (err, res) => {
            if (err) {
                throw err;
            }
            db.close();
        })
    })
}

// insertListInCollection().then(
// );