FORMAT FOR ID 

PAKISTAN -> PARENTID -> PK

PROVINCES:

AzadKashmir -> ID -> PKAK
Balochistan -> ID -> PKB
Federally Administered Tribal Areas -> ID -> PKF
Gilgit Baltistan -> ID -> PKGB
Islamabad -> ID -> PKI
Khyber Pakhtunkhwa -> ID -> PKKP
Punjab -> ID -> PKP
Sindh -> ID -> PKS

CITIES: 

AzadKashmir -> ID -> PKAK1, PKAK2, PKAK3, ...
Balochistan -> ID -> PKB1, PKB2, PKB3, ...
Federally Administered Tribal Areas -> ID -> PKF1, PKF2, PKF3, ...
Gilgit Baltistan -> ID -> PKGB1, PKGB2, PKGB3, ...
Islamabad -> ID -> PKI1, PKI2, PKI3, ...
Khyber Pakhtunkhwa -> ID -> PKKP1, PKKP2, PKKP3, ..
Punjab -> ID -> PKP1, PKP2, PKP3, ...
Sindh -> ID -> PKS1, PKS2, PKS3, ...

SUBAREAS OF LAHORE:

Subareas of lahore -> ID -> PKPLHR1, PKPLHR2, PKPLHR3, ...

FORMAT -> 2 digit Pakistan ID + 1/2 digit Province ID + 1/2/3 digit City ID + ID in numbers

e.g ->	ID of Lahore subareas
	PK + P + LHR + 1
