import fs from 'fs'

export const appendToCSVFIle = async (filename, list) => {
    return await fs.promises.appendFile(filename, list, (err) => {
        if (err) {
            throw err;
        }
    });
}