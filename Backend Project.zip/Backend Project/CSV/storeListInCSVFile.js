import CsvWriter from "csv-writer";

// this stores csv writer object
const createCSVWriter = CsvWriter.createObjectCsvWriter;

// this stores provinces list
// in csv file
export const storeListInCSVFile = (filename, list) => {
    // this is the format 
    // which we will be 
    // following in csv file
    const csvWriter = createCSVWriter(
        {
            path: './' + filename,
            header: [
                {
                    id: 'id',
                    title: 'ID'
                }, {
                    id: 'name',
                    title: 'TITLE'
                }, {
                    id: 'parentId',
                    title: 'PARENTID'
                }
            ]           
        }
    );
    csvWriter.writeRecords(list).then();
}
