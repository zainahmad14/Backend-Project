// this dsiplays result
// in html format of table 
// on database
export const showInHTMLFormat = (list, res) => {
    const html = [
        '<!DOCTYPE html>',
        '<html lang = \'en\'>',
        '<head>',
        '<title>',
        'Users Info',
        '</title>',
        '<style>',
        'table, th, td {',
        'border: 1px solid black',
        '}',
        '</style>',
        '<body>',
        '<table>', 
        '<tr>',
        '<th>Sr. No</th>',
        '<th>ID</th>',
        '<th>NAME</th>',
        '<th>PARENTID</th>',
        '</tr>'
    ];
    let index = 0;
    while (index < list.length) {
        const element = '<tr>' + '<td>' + parseInt(index + 1) + '</td>' + '<td>' + list[index].id + '</td>' + '<td>' + list[index].name + '</td>' + '<td>' + list[index].parentId + '</td>'+ '</tr>';
        html.push(element);
        index++;
    }
    html.push('</table>');
    html.push('</body>');
    html.push('</html>');
    res.send(html.join(''))
} 