import fetch from 'node-fetch';
import { readListFromCSVFile } from '../CSV/readListFromCSVFile.js';
import { fetchSubAreasOfCities } from './fetchSubareasofLhr.js';

const readIDFromList = async (filename) => {
    const objectArray = [];
    return await readListFromCSVFile(filename).then(
        (list) => {
            const listArray = list.split('\n');
            listArray.shift();
            listArray.pop();
            for (list of listArray) {
                const listObject = list.split(',');
                const object = {
                    id: listObject[0]
                }
                //console.log('Object is: ', object);
                objectArray.push(object);
            }
            console.log('length is: '+ objectArray.length);
            fetchSubAreasOfCities(objectArray);
            //return objectArray;
        }
    );
}

const readIDFromAllLists = async (filenames) => {
    const IDList = [];
    let index = 0;
    //while (index < filenames.length) {
        IDList.concat(await readIDFromList(filenames[6]));
        //console.log(IDList);
    //}
    console.log('Now length is: ' + IDList.length);
    return await IDList;
}




const fetchCitiesSubAreasList = async () => {
    const filenames = [
        'AzadKashmir.csv',
        'Balochistan.csv',
        'Baltistan.csv',
        'FederalTribalAreas.csv',
        'Islamabad.csv',
        'KhyberPakhtunkhwa.csv',
        'Punjab.csv',
        'Sindh.csv'
    ]
    return readIDFromAllLists(filenames).then(
        (list) => {
            return list;
        }
    );
    // console.log(list);

}

fetchCitiesSubAreasList().then(
    (list) => console.log(list)
);









// this returns the list 
// as an array of object
export const list = async () => {
    const url = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R3780130';
    // this stores response from
    // url after fetching it
    const response = await fetch(url);
    // this stores response as
    // json object
    const jsonObject = await response.json();
    const list = [];
    let index = 0;
    // this stores json object in 
    // list
    while (index < jsonObject.module.length) {
        const object = {
            id: jsonObject.module[index].id,
            name: jsonObject.module[index].name,
            parentId: jsonObject.module[index++].parentId
        }
        list.push(object);
    }
    return list;
}