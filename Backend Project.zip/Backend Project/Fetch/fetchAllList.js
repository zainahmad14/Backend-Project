import { list } from "./fetchList.js";
import { storeListInCSVFile } from "../CSV/storeListInCSVFile.js";

// this contains urls of provinces
const provinceURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK';
// this contains urls of cities of provinces
const azadKashmirURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R3780130';
const balochistanURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R357968';
const federalTribalAreasURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R358004';
const gilgitBaltistanURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R80302264';
const islamabadURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R358002';
const khyberPakhtunkhwaURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R3780131';
const punjabURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R357988';
const sindhURL = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R357981';

// this stores list in 
// listArray after fetching
// all lists
export const listArray = async () => {
    // this stores provinces list
    // in Province.csv
    list(provinceURL).then(
        (list) => {
            storeListInCSVFile('Province.csv', list);
        }
    );
    // this stores cities of
    // azad kashmir in
    // AzadKashmir.csv
    list(azadKashmirURL).then(
        (list) => {
            storeListInCSVFile('AzadKashmir.csv', list);
        }
    );
    // this stores cities of
    // balochistan in
    // Balochistan.csv
    list(balochistanURL).then(
        (list) => {
            storeListInCSVFile('Balochistan.csv', list);
        }
    );
    // this store cities of
    // federal tribal areas
    // in FederalTribalAreas.csv
    list(federalTribalAreasURL).then(
        (list) => {
            storeListInCSVFile('FederalTribalAreas.csv', list);
        }
    );
    // this store cities of 
    // gilgit baltistan in
    // Baltistan.csv
    list(gilgitBaltistanURL).then(
        (list) => {
            storeListInCSVFile('Baltistan.csv', list);
        }
    );
    // this store cities of
    // islamabad in
    // Islamabad.csv
    list(islamabadURL).then(
        (list) => {
            storeListInCSVFile('Islamabad.csv', list);
        }
    );
    // this store cities of 
    // khyber pakhtunkhwa in
    // KhyberPakhtunkhwa,csv
    list(khyberPakhtunkhwaURL).then(
        (list) => {
            storeListInCSVFile('KhyberPakhtunkhwa.csv', list);
        }
    );
    // this stores cities of
    // punjab in
    // Punjab.csv
    list(punjabURL).then(
        (list) => {
            storeListInCSVFile('Punjab.csv', list);
        }
    );
    // this store cities of 
    // sindh in
    // Sindh.csv
    list(sindhURL).then(
        (list) => {
            storeListInCSVFile('Sindh.csv', list);
        }
    );
}