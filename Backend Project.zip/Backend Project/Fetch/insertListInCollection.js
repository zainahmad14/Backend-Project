import { storeListAsObjectArray } from '../CSV Object/storeListAsCSVObject.js';
import {default as mongodb} from 'mongodb';

const MongoClient = mongodb.MongoClient;
const url = 'mongodb://localhost:27017';


const subAreasOfLahoreModified = await storeListAsObjectArray('./Fetch/Lahore-subareas-modified.csv');

const myCollection = 'Cities';
MongoClient.connect(url, (err, db) => {
    if (err) {
        throw err;
    }
    const dbo = db.db('mydb');
    dbo.collection(myCollection).insertMany(subAreasOfLahoreModified, (err, res) => {
        if (err) {
            throw err;
        }
        db.close();
    });
});