import { list } from './fetchList.js'
import { storeListInCSVFile } from '../CSV/storeListInCSVFile.js';

export const fetchSubAreasOfCities = (listArray) => {
    const url = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=';    
    //const url = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R3780130';
    let startIndex = 0;
    let lastIndex = 244;
    // let startIndex = 246;
    // let lastIndex = 339;
    while (startIndex <= lastIndex) {
        list(url + listArray[startIndex++].id).then(
            (subAreasList) => {
                //storeListInCSVFile('LhrSubareas.csv', subAreasList);
                //console.log(subAreasList);
            }
        )
    }
}

//fetchSubAreasOfCities();