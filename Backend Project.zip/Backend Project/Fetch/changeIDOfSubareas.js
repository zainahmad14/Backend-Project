import { storeListAsObjectArray } from "../CSV Object/storeListAsCSVObject.js";
import { storeListInCSVFile } from "../CSV/storeListInCSVFile.js";

const subAreasList = await storeListAsObjectArray('./Fetch/Lahore/lahore-subareas.csv').then(
    (list) => {
        return list;
    }
);

const punjabCitiesList = await storeListAsObjectArray('./Punjab.csv').then(
    (list) => {
        return list;
    }
);

const punjabModifiedCitiesList = await storeListAsObjectArray('./Replaced/Punjab.csv').then(
    (list) => {
        return list;
    }
);

const replaceIDInSubAreasList = (subAreasList, punjabCitiesList, punjabModifiedCitiesList) => {
    let startingIndex1 = 0;
    let endingIndex1 = subAreasList.length;
    while (startingIndex1 < endingIndex1)  {
        let startingIndex2 = 0;
        let endingIndex2 = punjabCitiesList.length;
        let flag = false;
        while ((startingIndex2 < endingIndex2) && (flag == false)) {
            if (subAreasList[startingIndex1].parentId == punjabCitiesList[startingIndex2].id + '\r') {
                subAreasList[startingIndex1].id = 'PKPLHR' + (startingIndex1 + 1).toString();
                subAreasList[startingIndex1].parentId = punjabModifiedCitiesList[startingIndex2].id;
                flag = true;
            }
            startingIndex2++;
        }
        startingIndex1++;
    }
    return subAreasList;
}

storeListInCSVFile('Punjab-subareas-modified.csv', replaceIDInSubAreasList(subAreasList, punjabCitiesList, punjabModifiedCitiesList));

//replaceIDInSubAreasList(subAreasList, punjabCitiesList, punjabModifiedCitiesList);


//console.log(subAreasList);
//console.log(punjabCitiesList);
//console.log(punjabModifiedCitiesList);