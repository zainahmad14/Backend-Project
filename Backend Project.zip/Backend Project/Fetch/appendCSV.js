import { appendToCSVFIle } from "../CSV/appendToCSVFile.js";
import { readListFromCSVFile } from "../CSV/readListFromCSVFile.js";
import { storeListAsObjectArray } from '../CSV Object/storeListAsCSVObject.js';

let startIndex = 0;
let endIndex = 244;

// let startIndex = 245;
// let endIndex = 339;

const subareas = [];

const storeSubAreasList = (list) => {
    let index = 0;
    while (index < list.length) {
        subareas.push(list[index++]);
    }
    //console.log(subareas.length);
}




const storeSubAreas = async () => { 
    while (startIndex++ < endIndex) {
        storeListAsObjectArray('./Fetch/LahoreSubAreas/LhrSubareas' + startIndex.toString() + '.csv').then(
            (list) => {
                storeSubAreasList(list);
                if (startIndex == endIndex) {
                    console.log(subareas);
                }
            }
        );
        
    }
    //console.log(subareas);
    return await subareas;
}

storeSubAreas().then(
    (list) => {
        console.log(subareas);
    }
);


// storeListAsObjectArray('./Fetch/LahoreSubAreas/LhrSubareas247.csv').then(
//     (list) => appendToCSVFIle('new.csv', list)
// );