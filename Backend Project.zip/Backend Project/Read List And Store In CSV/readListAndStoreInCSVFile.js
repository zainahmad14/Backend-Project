import { storeListAsObjectArray } from './../CSV Object/storeListAsCSVObject.js'
import { storeListInCSVFile } from '../CSV/storeListInCSVFile.js';


// these are the PID
// of all provinces
const newProvincePID = 'PK';
const newAzadKashmirID = 'PKAK';
const newBalochistanID = 'PKB';
const newFederalTribalAreasID = 'PKF';
const newGilgitBaltistanID = 'PKGB';
const newIslamabadID ='PKI';
const newKhyberPakhtunkhwaID = 'PKKP';
const newPunjabID = 'PKP';
const newSindhID = 'PKS';

// this contains information
// about filename, ID and PID
const ID = [
    {
        filename: 'Province.csv',
        PID: 'PK1',
        ID: [
            newAzadKashmirID,
            newBalochistanID,
            newFederalTribalAreasID,
            newGilgitBaltistanID,
            newIslamabadID,
            newKhyberPakhtunkhwaID,
            newPunjabID,
            newSindhID
        ]
    }, {
        filename: 'AzadKashmir.csv',
        PID: newAzadKashmirID
    }, {
        filename: 'Balochistan.csv',
        PID: newBalochistanID
    }, {
        filename: 'FederalTribalAreas.csv',
        PID: newFederalTribalAreasID
    }, {
        filename: 'Baltistan.csv',
        PID: newGilgitBaltistanID
    }, {
        filename: 'Islamabad.csv',
        PID: newIslamabadID
    }, {
        filename: 'KhyberPakhtunkhwa.csv',
        PID: newKhyberPakhtunkhwaID
    }, {
        filename: 'Punjab.csv',
        PID: newPunjabID
    }, {
        filename: 'Sindh.csv',
        PID: newSindhID
    }
]

// this replaces ID with newID
// and store in csv file
export const replaceIDAndStoreInCSVFIle = async () => {
    storeListAsObjectArray('./Cities/' + ID[0].filename).then(
        (objectArray) => {
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = newProvincePID;
                // this replaces oldID with newID
                objectArray[index].id = ID[0].ID[index]
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[0].filename, objectArray);
        }
    );
    // this replaces the id of ID[1]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[1].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[1].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[1].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[1].filename, objectArray);
        }
    );
    // this replaces the id of ID[2]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[2].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[2].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[2].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[2].filename, objectArray);
        }
    );
    // this replaces the id of ID[3]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[3].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[3].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[3].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[3].filename, objectArray);
        }
    );
    // this replaces the id of ID[1]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[4].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[4].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[4].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[4].filename, objectArray);
        }
    );
    // this replaces the id of ID[5]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[5].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[5].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[5].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[5].filename, objectArray);
        }
    );
    // this replaces the id of ID[6]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[6].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[6].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[6].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[6].filename, objectArray);
        }
    );
    // this replaces the id of ID[7]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[7].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[7].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[7].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[7].filename, objectArray);
        }
    );
    // this replaces the id of ID[8]
    // with new id
    storeListAsObjectArray('./Cities/' + ID[8].filename).then(
        (objectArray) => {
            const oldPID = objectArray[0].parentID;
            let index = 0;
            while (index < objectArray.length) {
                // this replaces oldPID with newPID
                objectArray[index].parentId = ID[8].PID;
                // this replaces oldID with newID
                objectArray[index].id = ID[8].PID + parseInt(index + 1);
                index++;
            }
            storeListInCSVFile('Replaced/' + ID[8].filename, objectArray);
        }
    );
}
