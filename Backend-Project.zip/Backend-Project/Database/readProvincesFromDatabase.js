import { showInHTMLFormat } from '../HTML Format/htmlFormat.js';
import {default as mongodb} from 'mongodb';
const MongoClient = mongodb.MongoClient;
const url = 'mongodb://localhost:27017';

// this reads all provinces from 
// database and displays it on
// server
export const readProvincesFromDatabase = (res) => {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            throw err;
        }
        const dbo = db.db('mydb');
        const myQuery = {
            parentId: 'PK'
        }
        dbo.collection('Cities').find(myQuery).toArray((err, result) => {
            if (err) {
                throw err;
            }
            // this displays result 
            // in table format of html
            // page on server
            showInHTMLFormat(result, res);
            db.close();
        })
    })
}