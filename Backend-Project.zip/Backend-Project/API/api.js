import { readProvincesFromDatabase } from '../Database/readProvincesFromDatabase.js';
import { readCitiesFromDatabase } from '../Database/readCitiesFromDatabase.js';
import { readSpecificProvincesFromDatabase } from '../Database/readSpecificProvinceFromDatabase.js';
import { readSpecificCitiesFromDatabase } from './readSpecificCitiesFromDatabase.js';
import express from 'express';

// this calls api
export const apiCalling = () => {
    const app = express();
    
    const __dirname = 'C:/Users/hp/Desktop/My Impact Meter/Server Practice/Cities';
    
    // // this displays landing page
    // app.get('/', (req, res) => {
    //     res.sendFile(__dirname + '/HTML/landingPage.html');  
    // })

    // // this displays all provinces
    // app.get('/provinces', (req, res) => {
    //     readProvincesFromDatabase(res);
    // })

    // // this displays all cities
    // app.get('/cities',(req, res) => {
    //     readCitiesFromDatabase(res);
    // })

    // // this displays city of specific province
    // app.get('/provinces/:id', (req, res) => {
    //     const id = req.params.id;
    //     readSpecificProvincesFromDatabase(res, id);
    // })

    // // this displays specific id
    // app.get('/cities/:id', (req, res) => {
    //     const id = req.params.id;
    //     readSpecificCitiesFromDatabase(res, id);
    // })

    //api format
    // localhost:3001/ => this displays landing page
    // localhost:3001/city/ => this displays all cities of all provinces
    // localhost:3001/city/id=PKI1 => this displays specific city whose id  = PKI1
    // localhost: 3001/city/parentid=PKI => this displays cities of specific province whose parentid  = PKI

    // this displays landing page
    app.get('/', (req, res) => {
        res.sendFile(__dirname + '/HTML/landingPage.html');  
    })

    app.get('/city', (req, res) => {
        const id = req.params.id || req.query.id;
        // this display all cities of all provinces
        if (!req.query.parentid && !req.query.id) {
            readCitiesFromDatabase(res);
        }
        //this displays specific city 
        else if (!req.query.parentid) {
            readSpecificCitiesFromDatabase(res, id);
        }
        // this displays all cities of specific province
        else {
            readSpecificProvincesFromDatabase(res, req.query.parentid);
        } 
    })


    const port = 3001;

    // this listens on port
    app.listen(port, () => {
        console.log('This server is listening on port ' + port);
    })
}
