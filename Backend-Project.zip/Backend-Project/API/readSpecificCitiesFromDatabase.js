import { showInHTMLFormat } from '../HTML Format/htmlFormat.js';
import {default as mongodb} from 'mongodb';
const MongoClient = mongodb.MongoClient;
const url = 'mongodb://localhost:27017';

// this reads specific city
// from database and 
// displays it on server
export const readSpecificCitiesFromDatabase = (res, ID) => {
    MongoClient.connect(url, (err, db) => {
        if (err) {
            throw err;
        }
        const dbo = db.db('mydb');
        const myQuery = {
            id: ID
        }
        dbo.collection('Cities').find(myQuery).toArray((err, result) => {
            if (err) {
                throw err;
            }
            showInHTMLFormat(result, res);
            db.close();
        })
    })
}