import { readListFromCSVFile } from "../CSV/readListFromCSVFile.js";

// this stores list from csv file
// as object array
export const storeListAsObjectArray = async (filename) => {
    // this stores list 
    const objectArray = [];
    // this return list from csv file
    // which is pushed to objectArray 
    return await readListFromCSVFile(filename).then(
        (list) => {
            const listArray = list.split('\n');
            // this removes the titles of columns
            // from listArray
            listArray.shift();
            // this removes the last row from
            // listArray which is empty
            listArray.pop();
            // this push each row from csv file
            // in objectArray
            for (list of listArray) {
                const listObject = list.split(',');
                const object = {
                    id: listObject[0],
                    name: listObject[1],
                    parentId: listObject[2]
                }
                objectArray.push(object);
            } 
            return objectArray;
        }
    );
}

// storeListAsObjectArray('Province.csv').then(
//     (csvObject) => {
//         console.log(csvObject);
//     }
// );

