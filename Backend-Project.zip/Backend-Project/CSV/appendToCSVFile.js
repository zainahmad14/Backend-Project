import fs from 'fs'

export const appendToCSVFIle = (filename, list) => {
    return await fs.promises.appendFile(filename, list, (err) => {
        if (err) {
            throw err;
        }
    });
}