import fs from 'fs';

// this return array of string
// from csv file
export const readListFromCSVFile = async (filename) => {
    return await fs.promises.readFile('./../' + filename, 'utf-8');
}
