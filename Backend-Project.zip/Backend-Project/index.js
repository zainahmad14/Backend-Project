import { listArray } from './Fetch/fetchAllList.js'
import { replaceIDAndStoreInCSVFIle } from './Read List And Store In CSV/readListAndStoreInCSVFile.js'
import { insertListInCollection } from './Database/insertListInCollection.js';
import { apiCalling } from './API/api.js';

// this fetch all lists from
// url and store it in their
// respective csv files

// listArray().then();

// // this replaces id and parentId 
// // from csv files and stores them
// // in new csv file

// replaceIDAndStoreInCSVFIle();

// // this inserts all list in collection
// // of datbase

// insertListInCollection().then();

//api format
// localhost:3001/ => this displays landing page
// localhost:3001/city/ => this displays all cities of all provinces
// localhost:3001/city/id=PKI1 => this displays specific city whose id  = PKI1
// localhost: 3001/city/parentid=PKI => this displays cities of specific province whose parentid  = PKI

// this calls api's

apiCalling();

