import { list } from './fetchList.js'
import { storeListInCSVFile } from '../CSV/storeListInCSVFile.js';

export const fetchSubAreasOfCities = (listArray) => {
    const url = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=';    
    //const url = 'https://member.daraz.pk/locationtree/api/getSubAddressList?countryCode=PK&addressId=R3780130';
    let index = 0;
    while (index < listArray.length) {
        list(url + listArray[index++].id).then(
            (subAreasList) => {
                //storeListInCSVFile('List.')
                console.log(subAreasList);
            }
        )
    }
}

//fetchSubAreasOfCities();