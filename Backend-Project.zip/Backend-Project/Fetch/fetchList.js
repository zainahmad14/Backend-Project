import fetch from 'node-fetch';

// this returns the list 
// as an array of object
export const list = async (url) => {
    // this stores response from
    // url after fetching it
    const response = await fetch(url);
    // this stores response as
    // json object
    const jsonObject = await response.json();
    console.log(jsonObject);
    const list = [];
    let index = 0;
    // this stores json object in 
    // list
    while (index < jsonObject.module.length) {
        const object = {
            id: jsonObject.module[index].id,
            name: jsonObject.module[index].name,
            parentId: jsonObject.module[index++].parentId
        }
        list.push(object);
    }
    return list;
}